package com.example.graduation1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

//자모음 추출 코드
public class SeparateJaMo extends AppCompatActivity {
    TextView textOutput;
    static String temp;

    //private ImageGridAdapter imageGridAdapter = null;
    //private GridView gridViewImg = null;


    //초성, 중성, 종성의 배열
    final static String[] Cho = {"ㄱ", "ㄲ", "ㄴ,", "ㄷ", "ㄸ", "ㄹ", "ㅁ",
            "ㅂ", "ㅃ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅉ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"};

    final static String[] Joong = {"ㅏ", "ㅐ", "ㅑ", "ㅒ", "ㅓ",
            "ㅔ", "ㅕ", "ㅖ", "ㅗ", "ㅘ", "ㅙ", "ㅚ", "ㅛ", "ㅜ",
            "ㅝ", "ㅞ", "ㅟ", "ㅠ", "ㅡ", "ㅢ", "ㅣ"};

    final static String[] Jong = {"", "ㄱ", "ㄲ", "ㄳ", "ㄴ",
            "ㄵ", "ㄶ", "ㄷ", "ㄹ", "ㄺ", "ㄻ", "ㄼ", "ㄽ", "ㄾ", "ㄿ", "ㅀ",
            "ㅁ", "ㅂ", "ㅄ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jihwa);

        Intent receive_intent = getIntent();
        String temp = receive_intent.getStringExtra("textSend");
        textOutput = findViewById(R.id.textOutput);
        textOutput.setText(temp); //입력받은 내용 보여줌

        //자모 분리 시작
        String text = temp;
        //String[] sep = new String[255];
        List<String> sepList = new ArrayList<>();

        for (int a = 0; a < text.length(); a++) { //ex.졸:일때
            char uni = text.charAt(a); //a의 문자를 반환
            //한글일 경우 실행
            //string 타입으로 형변환 시켜서 리스트에 추가
            if (uni >= 0xAC00) {
                uni = (char) (uni - 0xAC00);
                sepList.add(String.valueOf((char) (uni / 28 / 21))); //ㅈ
                sepList.add(String.valueOf((char) (uni / 28 % 21))); //ㅗ
                sepList.add(String.valueOf((char) (uni % 28))); //ㄹ
                //sep[ㅈ,ㅗ,ㄹ...]
            }
        }
        String[] sepArray = sepList.toArray(new String[0]); //리스트-> 배열 변환
        //지화 사진 이미지 파일들의 리소스 id 값의 배열(일단 리스트로 생성)
        ArrayList<Integer> jihwaImgList = new ArrayList<>();

        //사진 for문-배열에 담긴 값 가져와서 지화 사진과 매칭
        // String sep[]
        //sep배열에 있는 값 하나씩 가져와서
        //여기도 리스트 -> 배열 써야 될듯
        for (int b=0; b< sepArray.length; b++){
            String textArray = sepArray[b];
            //배열에 있는 글자가 "( )"일 때 해당되는 사진을 배열에 넣어주기
            switch(textArray) {
                case "ㄱ":
                    //리스트에 이미지 리소스 id 추가
                    jihwaImgList.add(R.drawable.r); break;
                case "ㄴ":
                    jihwaImgList.add(R.drawable.s); break;
                case "ㄷ":
                    jihwaImgList.add(R.drawable.e); break;
                case "ㄹ":
                    jihwaImgList.add(R.drawable.f); break;
                case "ㅁ":
                    jihwaImgList.add(R.drawable.a); break;
                case "ㅂ":
                    jihwaImgList.add(R.drawable.q); break;
                case "ㅅ":
                    jihwaImgList.add(R.drawable.t); break;
                case "ㅇ":
                    jihwaImgList.add(R.drawable.d); break;
                case "ㅈ":
                    jihwaImgList.add(R.drawable.w); break;
                case "ㅊ":
                    jihwaImgList.add(R.drawable.c); break;
                case "ㅋ":
                    jihwaImgList.add(R.drawable.z); break;
                case "ㅌ":
                    jihwaImgList.add(R.drawable.x); break;
                case "ㅍ":
                    jihwaImgList.add(R.drawable.v); break;
                case "ㅎ":
                    jihwaImgList.add(R.drawable.g); break;
                case "ㄲ":
                    jihwaImgList.add(R.drawable.rr); break;
                case "ㄸ":
                    jihwaImgList.add(R.drawable.ee); break;
                case "ㅆ":
                    jihwaImgList.add(R.drawable.tt); break;
                case "ㅃ":
                    jihwaImgList.add(R.drawable.qq); break;
                case "ㅉ":
                    jihwaImgList.add(R.drawable.ww); break;
                case "ㅏ":
                    jihwaImgList.add(R.drawable.k); break;
                case "ㅑ":
                    jihwaImgList.add(R.drawable.i); break;
                case "ㅓ":
                    jihwaImgList.add(R.drawable.j); break;
                case "ㅕ":
                    jihwaImgList.add(R.drawable.u); break;
                case "ㅗ":
                    jihwaImgList.add(R.drawable.h); break;
                case "ㅛ":
                    jihwaImgList.add(R.drawable.y); break;
                case "ㅜ":
                    jihwaImgList.add(R.drawable.n); break;
                case "ㅠ":
                    jihwaImgList.add(R.drawable.b); break;
                case "ㅡ":
                    jihwaImgList.add(R.drawable.m); break;
                case "ㅣ":
                    jihwaImgList.add(R.drawable.l); break;
                case "ㅐ":
                    jihwaImgList.add(R.drawable.o); break;
                case "ㅒ":
                    jihwaImgList.add(R.drawable.oo); break;
                case "ㅔ":
                    jihwaImgList.add(R.drawable.p); break;
                case "ㅖ":
                    jihwaImgList.add(R.drawable.pp); break;
                case "ㅢ":
                    jihwaImgList.add(R.drawable.ml); break;
                case "ㅚ":
                    jihwaImgList.add(R.drawable.hl); break;
                case "ㅟ":
                    jihwaImgList.add(R.drawable.nl); break;
                case "ㅘ":
                    jihwaImgList.add(R.drawable.hk); break;
                case "ㅙ":
                    jihwaImgList.add(R.drawable.ho); break;
                case "ㅝ":
                    jihwaImgList.add(R.drawable.nj); break;
                default:
                    jihwaImgList.add(0);
            }
            //리스트-> 배열 바꿔주기 - 필요한지 나중에 확인
            //Object[] jihwaImgArray = jihwaImgList.toArray();
        }
        //int[] jihwaImgArray = Integer.parseInt(jihwaImgList.toArray());//(new Integer[jihwaImgList.size()]);
        int[] jihwaImgArray = new int[0];
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            jihwaImgArray = jihwaImgList.stream().mapToInt(Integer::intValue).toArray();
        }

        //만들어진 최종 배열 이용해서 그리드뷰로 화면에 띄워주는 부분
        GridView gridViewImg = findViewById(R.id.gridViewImg); //xml연결
        ImageGridAdapter imageGridAdapter = new ImageGridAdapter(this, jihwaImgArray); //adapter 선언
        gridViewImg.setAdapter(imageGridAdapter); //adapter 연결

    }


}
