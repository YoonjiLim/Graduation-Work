package com.example.graduation1;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class ImageGridAdapter extends BaseAdapter {
    private final Context context;

    private final int[] jihwaImgArray;

    public ImageGridAdapter(Context context, int[] jihwaImgArray){
        this.context = context;
        this.jihwaImgArray = jihwaImgArray;
    }

    public int getCount(){
        //return (null!= jihwaImgArray) ? jihwaImgArray.length:0;
        return jihwaImgArray.length;
    }

    public Object getItem(int position){
        //return (null!=jihwaImgArray) ? jihwaImgArray[position]:0;
        return null;
    }
    public long getItemId(int position){
        //return position;
        return 0;
    }

    public View getView(int position, View convertView, ViewGroup parent){
        ImageView imageView;
        //if(null!= convertView)
        //    imageView = (ImageView) convertView;
        //else{
        //    Bitmap bmap = BitmapFactory.decodeResource(context.getResources(),jihwaImgArray[position]);
        //    bmap = Bitmap.createScaledBitmap(bmap, 250, 250, false);
        //    imageView = new ImageView(context);
        //    imageView.setAdjustViewBounds(true);
        //    imageView.setImageBitmap(bmap);
        if(convertView == null){
            //아직 화면에 어떻게 보여지는지 확인을 못해서 사이즈 설정은 임시로 아무 숫자나 넣음
            imageView = new ImageView(context);
            imageView.setLayoutParams(new GridView.LayoutParams(250,250));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8,8,8,8);
            }
        else{
            imageView = (ImageView) convertView;
        }
        imageView.setImageResource(jihwaImgArray[position]);
        return imageView;
    }
}